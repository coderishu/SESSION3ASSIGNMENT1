package com.example.ishumishra97.session3assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity{

     ImageView picview;
    Button button;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        picview=(ImageView)findViewById(R.id.imageView);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (picview.getVisibility() == View.INVISIBLE){
                    picview.setVisibility(View.VISIBLE);
                } else if (picview.getVisibility() == View.VISIBLE) {
                    picview.setVisibility(View.INVISIBLE);
                }
            }
        });

    }
}
